import { KnobArchitectPreset, TextureArchetype } from '../types/skin';
import { GENERATED_1000_PRESETS } from './importedSource2Presets';

// Imported from dh-texture-knbs. IDs live above the generated catalog range so
// existing saved selections keep their current mapping.
const milestoneKnobPreset: KnobArchitectPreset = {
  id: 10001,
  name: 'Orbit Vernier · Imported #10001',
  category: 'Precision Industrial · Source Import',
  style: 'OrbitVernier',
  bodyColor: '#CBD5E1',
  accentColor: '#F59E0B',
  pointerColor: '#00FF66',
  bezelWidth: 3,
  tickCount: 35,
  tickSpread: 245,
  pointerThickness: 3.6,
  pointerLengthRatio: 0.74,
  centerCapRatio: 0.34,
  glowIntensity: 0.7,
  shadowDepth: 12,
  metalRoughness: 0.4,
  description: 'Dual-scale aerospace vernier with 36 engraved divisions and a calibrated orbital readout.'
};

const sourceOneStyles = [
  'OrbitVernier',
  'SpectralDial',
  'GlassCore',
  'PrecisionStack',
  'HexCore',
  'PulseHalo'
] as const;

const sourceOneCategories = [
  'Precision Industrial',
  'Cyberpunk Glowing',
  'Vintage Bakelite',
  'Studio Anodized',
  'Minimalist Bauhaus',
  'Aerospace Dial',
  'Analog Console',
  'Futuristic HUD',
  'Analog Hardware',
  'Liquid Organic',
  'Cyber Minimal',
  'Vintage Classic',
  'Industrial Machined',
  'Optical Precision',
  'Boutique Studio'
];

const sourceOnePalettes = [
  { body: '#242832', accent: '#E8A13A', pointer: '#E63946' },
  { body: '#161922', accent: '#00E5FF', pointer: '#FF007F' },
  { body: '#2B2622', accent: '#D4AF37', pointer: '#E05A47' },
  { body: '#181C16', accent: '#00FF9D', pointer: '#FFCC00' },
  { body: '#1F1714', accent: '#E07A5F', pointer: '#E65100' },
  { body: '#1A1824', accent: '#B347FF', pointer: '#00F0FF' },
  { body: '#1F2228', accent: '#38BDF8', pointer: '#F43F5E' },
  { body: '#141416', accent: '#A3B18A', pointer: '#D4AF37' },
  { body: '#EAE6DF', accent: '#FF2BD6', pointer: '#E6402B' },
  { body: '#CBD5E1', accent: '#F59E0B', pointer: '#00FF66' },
  { body: '#D4D4D8', accent: '#E8A13A', pointer: '#FF3366' },
  { body: '#F5E7CC', accent: '#38BDF8', pointer: '#FF9900' },
  { body: '#FAF5EB', accent: '#D4AF37', pointer: '#38BDF8' }
];

const sourceOneNames = [
  'Master Level', 'Filter Cutoff', 'Resonance Peak', 'Drive Saturation',
  'Mix Balance', 'Time Constant', 'Feedback Loop', 'Modulation Depth',
  'Tape Flutter', 'Harmonic Shape', 'Pre-Delay', 'Color Dispersion',
  'High Damping', 'Low Contour', 'Spatial Spread', 'Decay Envelope',
  'Rotary Precision Dial', 'HUD Segmented Ring', 'Boutique Fluted Cap',
  'Obsidian Stepped Rotor', 'Quantum Arc Indexer', 'Vintage Bakelite Pot',
  'Milled Aerospace Lathe', 'Liquid Core Indicator', 'Laser Bevel Potentiometer',
  'Anodized Billet Wheel', 'Minimalist Specular Dot', 'Studio Gold Master'
];

const sourceOneKnobPresets: KnobArchitectPreset[] = Array.from({ length: 3000 }).flatMap((_, i): KnobArchitectPreset[] => {
  const sourceStyleIndex = i % 16;
  if (sourceStyleIndex < 10) return [];

  const style = sourceOneStyles[sourceStyleIndex - 10];
  const palette = sourceOnePalettes[i % sourceOnePalettes.length];
  const category = sourceOneCategories[i % sourceOneCategories.length];
  const sourceId = i + 1;
  const tickCount = 5 + ((i * 3) % 25);

  return [{
    id: 11000 + sourceId,
    name: `${sourceOneNames[i % sourceOneNames.length]} ${style} · Imported #${String(sourceId).padStart(4, '0')}`,
    category: `${category} · Source Import`,
    style,
    bodyColor: palette.body,
    accentColor: palette.accent,
    pointerColor: palette.pointer,
    bezelWidth: parseFloat((1 + ((i * 17) % 35) / 10).toFixed(1)),
    tickCount,
    tickSpread: 220 + ((i * 13) % 80),
    pointerThickness: parseFloat((1.8 + ((i * 19) % 36) / 10).toFixed(1)),
    pointerLengthRatio: parseFloat((0.52 + ((i * 23) % 44) / 100).toFixed(2)),
    centerCapRatio: parseFloat((0.2 + ((i * 29) % 38) / 100).toFixed(2)),
    glowIntensity: parseFloat((0.15 + ((i * 31) % 85) / 100).toFixed(2)),
    shadowDepth: parseFloat((2 + (i % 14)).toFixed(1)),
    metalRoughness: parseFloat((0.15 + ((i * 47) % 75) / 100).toFixed(2)),
    description: `Imported rotary dial featuring ${style} geometry with ${tickCount} calibrated ticks and ${category.toLowerCase()} acoustics.`
  }];
});

const sourceTwoKnobPresets: KnobArchitectPreset[] = GENERATED_1000_PRESETS.knobs.map(
  (preset, index) => ({
    ...preset,
    id: 30001 + index,
    name: `${preset.name.replace(/ #\d+$/, '')} · Imported #${String(index + 1).padStart(4, '0')}`,
    category: `${preset.category} · Source Import`
  })
);

export const importedKnobPresets: KnobArchitectPreset[] = [
  milestoneKnobPreset,
  ...sourceOneKnobPresets,
  ...sourceTwoKnobPresets
];

const milestoneTexturePreset: TextureArchetype = {
  id: 10001,
  name: 'Singularity Ion Drive · Imported #10001',
  category: 'Cosmic Polar Ray',
  patternType: 'spectralbloom-singularity',
  baseModel: 'SpectralBloom',
  primaryTint: '#0C0A14',
  secondaryTint: '#05040A',
  accentTint: '#A855F7',
  roughness: 0.15,
  contrast: 0.85,
  grainDensity: 0.18,
  noiseOctaves: 2,
  blendMode: 'overlay',
  vignette: 0.12,
  liquidAngle: 0,
  seed: 87463,
  description: 'Deep gravitational space frame with cosmic ultraviolet refraction and polarized event-horizon telemetry.',
  inspirationTitle: 'Cosmic Quantum Reference',
  inspirationLink: 'https://shaders.com'
};

const sourceTwoTexturePresets: TextureArchetype[] = GENERATED_1000_PRESETS.textures
  .slice(1)
  .map((preset, index) => ({
    ...preset,
    id: 30002 + index,
    name: `${preset.name.replace(/ #\d+$/, '')} · Imported #${String(index + 2).padStart(4, '0')}`
  }));

// The first source-2 texture was imported for Milestone 1; the remaining 999
// entries retain their procedural model, seed, and attribution metadata.
export const importedTexturePresets: TextureArchetype[] = [
  milestoneTexturePreset,
  ...sourceTwoTexturePresets
];
